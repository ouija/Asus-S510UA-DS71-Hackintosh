本公举主要配合NVRAM中配置实现自动连接wifi
使用场景一：仅连接1个wifi：
使用Hackintool工具中NVRAM选项卡，点击下面“+”图标，增加两个值 WiFi-SSID和WiFi-PW分别填写无线网络名称和密码。执行install.command后重启即可实现自动连接。
使用场景二：连接有限几个wifi，通过启动菜单选择不同的OC配置文件启动：
在每个OC配置文件中增加如下配置，在ADD增加WiFi-SSID和WiFi-PW分别对应无线网络名称和密码，和Block中增加WiFi-SSID和WiFi-PW。通过搜索boot-args添加删除即可。
	<key>NVRAM</key>
	<dict>
		<key>Add</key>
		<dict>
			<key>7C436110-AB2A-4BBB-A880-FE41995C9F82</key>
			<dict>
				<key>WiFi-SSID</key>
				<string>My-WiFi-SSID</string>
				<key>WiFi-PW</key>
				<string>MyPassword</string>
				<key>boot-args</key>
				<string>-cdfon -igfxmlr</string>
			</dict>
		</dict>
		<key>Block</key>
		<dict>
			<key>7C436110-AB2A-4BBB-A880-FE41995C9F82</key>
			<array>
				<string>boot-args</string>
				<string>WiFi-SSID</string>
				<string>WiFi-PW</string>
			</array>
		</dict>