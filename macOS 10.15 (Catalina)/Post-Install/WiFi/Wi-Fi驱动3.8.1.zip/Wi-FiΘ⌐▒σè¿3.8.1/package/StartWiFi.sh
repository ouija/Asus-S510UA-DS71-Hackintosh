#!/bin/bash

thisDir=/usr/local
password=rootpassword

nvram  WiFi-SSID 2>/dev/null 1>/dev/null
if [ $? -ne 0 ]; then
    exit 1
fi
nvram  WiFi-PW 2>/dev/null 1>/dev/null
if [ $? -ne 0 ]; then
    exit 1
fi

ssid=$(nvram  WiFi-SSID | sed -e 's/WiFi-SSID	//g'|sed -e 's/%00$//g')

psw=$(nvram  WiFi-PW | sed -e 's/WiFi-PW	//g'|sed -e 's/%00$//g')
if [ "X$ssid" == "X" ];then
	exit 1
fi
if [[ -d "/tmp/AppleIntelWiFi.kext" ]];then
   echo "$password" | sudo -S  rm -r /tmp/AppleIntelWiFi.kext
fi

#xattr -c -r "$thisDir/*"
echo "$password" | sudo -S cp -r "$thisDir/AppleIntelWiFi.kext" /tmp

echo "$password" | sudo -S /usr/libexec/PlistBuddy -c "Set :IOKitPersonalities:AppleIntelWiFi:IFConfig:NWID ${ssid}" /tmp/AppleIntelWiFi.kext/Contents/Info.plist
echo "$password" | sudo -S /usr/libexec/PlistBuddy -c "Set :IOKitPersonalities:AppleIntelWiFi:IFConfig:WPAKEY ${psw}" /tmp/AppleIntelWiFi.kext/Contents/Info.plist

if [ "X$psw" == "X" ];then
		echo "$password" | sudo -S /usr/libexec/PlistBuddy -c "Set :IOKitPersonalities:AppleIntelWiFi:IFConfig:WPA/WPA2 false" /tmp/AppleIntelWiFi.kext/Contents/Info.plist
else
		echo "$password" | sudo -S /usr/libexec/PlistBuddy -c "Set :IOKitPersonalities:AppleIntelWiFi:IFConfig:WPA/WPA2 true" /tmp/AppleIntelWiFi.kext/Contents/Info.plist
fi


echo "$password" | sudo -S chmod -R 755 "/tmp"/AppleIntelWiFi.kext
echo "$password" | sudo -S chmod 644 "/tmp"/AppleIntelWiFi.kext/Contents/Info.plist
echo "$password" | sudo -S chmod 644 "/tmp"/AppleIntelWiFi.kext/Contents/_CodeSignature/CodeResources

echo "$password" | sudo -S chown -R root:wheel "/tmp"/AppleIntelWiFi.kext
echo "$password" | sudo -S xattr -c -r "/tmp"/AppleIntelWiFi.kext
echo "$password" | sudo -S codesign --force --deep --sign - /tmp/AppleIntelWiFi.kext
echo "$password" | sudo -S kextutil -q "/tmp"/AppleIntelWiFi.kext